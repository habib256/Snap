#!/bin/bash

ARGS=${@:---aesl /usr/share/aseba/thymio_motion.aesl}

exec asebascratch "$ARGS"
