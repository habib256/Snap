                      Projects 
                       for the 
                    Thymio Robot
                        in the 
                Aseba Studio Environment

           Moti Ben-Ari and other contributors
              (see authors.txt for details)

    Copyright 2013-15 by Moti Ben-Ari and other contributors

    This work is licensed under the Creative Commons
    Attribution-ShareAlike 3.0 Unported License. To view a copy
    of this license, visit
    http://creativecommons.org/licenses/by-sa/3.0/
    or send a letter to Creative Commons, 444 Castro Street,
    Suite 900, Mountain View, California, 94041, USA.

Aseba Studio is a programming environment for the Thymio-II robot.
This archive contains the source code and documentation of projects
for the robot. These projects are designed to teach the basic concepts
of robotics algorithms. For more information on the Thymio-II and Aseba,
see: https://www.thymio.org/.
